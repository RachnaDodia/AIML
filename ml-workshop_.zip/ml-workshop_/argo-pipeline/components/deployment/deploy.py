
def _deployment(train_location, test_location):
    print('NOT Implemented')
    return 'success'
     
if __name__ == '__main__':
     print('Deployment data...')
     _deployment()